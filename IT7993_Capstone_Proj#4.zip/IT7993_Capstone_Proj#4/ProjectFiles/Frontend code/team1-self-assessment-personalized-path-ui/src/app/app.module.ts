import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LayoutModule } from '@angular/cdk/layout';
import { AngularMaterialModule } from './angular-material/angular-material.module';
import { FooterComponent } from './components/footer/footer.component';
import { HeaderComponent } from './components/header/header.component';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { CoursesDashboardComponent } from './components/courses-dashboard/courses-dashboard.component';
import { CourseDetailsComponent } from './components/course-details/course-details.component';
import { AttemptedQuizComponent } from './components/attempted-quiz/attempted-quiz.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CourselistComponent } from './components/courselist/courselist.component';
import { QuizComponent } from './components/quiz/quiz.component';
import { QuizService } from './services/quiz.service';
import { QuizplayComponent } from './components/quizplay/quizplay.component';



const appRoutes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: CoursesDashboardComponent},
  { path: 'coursedetails', component: CourseDetailsComponent},
  { path: 'attemptedquiz', component: AttemptedQuizComponent},
  { path: 'quizplay', component: QuizComponent},
  { path: 'quiz', component: QuizComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HeaderComponent,
    AttemptedQuizComponent,
    SignupComponent,
    CourseDetailsComponent,
    CoursesDashboardComponent,
    LoginComponent,
    CourselistComponent,
    QuizComponent,
    QuizplayComponent,
    CourselistComponent
  ],
  imports: [
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    AngularMaterialModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [QuizService],
  bootstrap: [AppComponent]
})
export class AppModule { }
