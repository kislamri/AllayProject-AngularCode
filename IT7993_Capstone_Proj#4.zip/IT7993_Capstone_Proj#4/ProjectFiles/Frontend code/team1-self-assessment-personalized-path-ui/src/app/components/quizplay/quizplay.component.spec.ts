import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuizplayComponent } from './quizplay.component';

describe('QuizplayComponent', () => {
  let component: QuizplayComponent;
  let fixture: ComponentFixture<QuizplayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuizplayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuizplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
