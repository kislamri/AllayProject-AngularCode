import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courses-dashboard',
  templateUrl: './courses-dashboard.component.html',
  styleUrls: ['./courses-dashboard.component.css']
})
export class CoursesDashboardComponent implements OnInit {
 
  pageId: number;
  constructor() { 
   
  }

  ngOnInit() {
    declartion:[
      CoursesDashboardComponent
    ]
   this.swtichPage(1);
  }

  swtichPage(pageId : number) {
    this.pageId = pageId;
}
}

