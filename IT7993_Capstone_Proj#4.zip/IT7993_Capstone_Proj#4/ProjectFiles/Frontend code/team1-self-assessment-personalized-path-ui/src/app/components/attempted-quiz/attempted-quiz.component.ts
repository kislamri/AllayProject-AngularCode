import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attempted-quiz',
  templateUrl: './attempted-quiz.component.html',
  styleUrls: ['./attempted-quiz.component.css']
})
export class AttemptedQuizComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
