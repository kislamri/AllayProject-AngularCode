import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
//import { Index } from '../models/index';
import { Quiz } from '../models/quiz';
import { Question } from '../models/question';
import { QuizConfig } from '../models/quiz-config';
import { Option } from '../models/option';



const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable()
export class QuizService {
  constructor(private http: HttpClient) {}

  get(url: string) {
    return this.http.get(url);
  }

  getBeginnerTopics() {
    return [
      { id: 1, name: 'Object Oriented Programming' },
      { id: 2, name: 'Working with collections' },
      { id: 3, name: 'Working with Data Types' },
      { id: 4, name: 'Java Fundamentals' },
      { id: 5, name: 'Control statements' },
    ];
  }

  getAll() {
    return [
      { id: '../../data/oops.json', name: 'Object Oriented Programming' },
      { id: '../../data/collections.json', name: 'Working with collections' },
      { id: '../../data/data_types.json', name: 'Working with Data Types' },
      { id: '../../data/java.json', name: 'Java Fundamentals' },
      { id: '../../data/control.json', name: 'Control statements' },
    ];
  }

  // Uses http.get() to load data
  getQuiz() {
    return this.http.get('http://localhost:8084/quiz/{id}');
  }

  // Uses http.post() to post data
  addQuiz(
    id: number,
    name: string,
    description: string,
    config: QuizConfig,
    questions: Question[],
  ) {
    this.http
      .post('http://localhost:8084/quiz', {
        id,
        name,
        description,
        config,
        questions,
      })
      .subscribe((responseData) => {
        console.log(responseData);
      });
    location.reload();
  }

  deleteCustomer(Quizid: string) {
    this.http
      .delete('http://localhost:8084/quiz/{id}/' + Quizid)
      .subscribe(() => {
        console.log('Deleted: ' + Quizid);
      });
    location.reload();
  }

  updateQuiz(
    id: number,
    name: string,
    description: string,
    config: QuizConfig,
    questions: Question[],
  ) {

    this.http
      .put('http://localhost:8084/quiz/{id}' + id, {
        id,
        name,
        description,
        config,
        questions,
      })
      .subscribe(() => {
        console.log('Updated: ' + id);
      });
    location.reload();
  }
}
