import { Component } from '@angular/core';

import { QuizComponent } from './components/quiz/quiz.component';
import { QuizService } from './services/quiz.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'sapl-v1';

  public optionsSelected =false;

  public level;
  public topics = [];
  public quizTopics = [];
  public selctedQuizes =[];
  public showQuiz = false
  constructor(private quizService: QuizService){}

  selectLevel(selected) {
    console.log(selected)
    if(selected === 1) {
      this.level = 'beginner';
      this.getTopics();
    }  else {
      this.level = 'intermediate';
      this.getQuizTopics();
    }
  }

  getQuizTopics() {
   this.quizTopics = this.quizService.getAll();
  }

  getTopics() {
    this.topics = this.quizService.getBeginnerTopics();
  }

  selectQuizTopic(qtopic) {
    const index = this.selctedQuizes.indexOf(qtopic);
    if(index <0 ){
      this.selctedQuizes.push(qtopic);
    } else {
      this.selctedQuizes.splice(index,1);
    }

    console.log(this.selctedQuizes);
  }

  startQuiz() {
    this.showQuiz = true;
  }
}
