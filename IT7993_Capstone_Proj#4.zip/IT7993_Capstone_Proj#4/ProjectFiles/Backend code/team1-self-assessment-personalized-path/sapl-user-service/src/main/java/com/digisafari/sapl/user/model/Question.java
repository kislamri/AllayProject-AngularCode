
package com.digisafari.sapl.user.model;

import java.util.List;

public class Question {

    private String id;
    private String title;
    private List<Option> options = null;
    private String correctOption;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<Option> getOptions() {
        return options;
    }

    public void setOptions(List<Option> options) {
        this.options = options;
    }

    public String getCorrectOption() {
        return correctOption;
    }

    public void setCorrectOption(String correctOption) {
        this.correctOption = correctOption;
    }

	@Override
	public String toString() {
		return "Question [id=" + id + ", title=" + title + ", options=" + options + ", correctOption=" + correctOption
				+ "]";
	}

    
    
}
