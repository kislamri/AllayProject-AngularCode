package excepetion;

public class QuizNotFoundException extends Exception {
	
	/*// added constructor to display feedback in 
	public QuizNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}*/

}
