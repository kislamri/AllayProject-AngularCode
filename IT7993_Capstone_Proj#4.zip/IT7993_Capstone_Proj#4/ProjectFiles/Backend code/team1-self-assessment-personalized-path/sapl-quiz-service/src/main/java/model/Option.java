package model;

public class Option {

	private Integer id;
	private String value;
	private boolean iscorrect;
	private String description;

	// no argument constructor
	public Option() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the iscorrect
	 */
	public boolean isIscorrect() {
		return iscorrect;
	}

	/**
	 * @param iscorrect the iscorrect to set
	 */
	public void setIscorrect(boolean iscorrect) {
		this.iscorrect = iscorrect;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	// To string() begin

	@Override
	public String toString() {
		return "Option [id=" + id + ", value=" + value + ", iscorrect=" + iscorrect + ", description=" + description
				+ "]";
	}

	// To string() end

}
